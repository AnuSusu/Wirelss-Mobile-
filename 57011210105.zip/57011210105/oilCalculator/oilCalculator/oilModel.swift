//
//  oilModel.swift
//  oilCalculator
//
//  Created by iClassroom on 11/8/16.
//  Copyright © 2016 iClassroom. All rights reserved.
//

import Foundation
protocol oilType {
    var type: String {get}
    
}
protocol PricePerUnit {
    var unitPrice:Double{get}
    
}
protocol amount {
    var amountTotal:Double{get}
}
protocol totalPrice {
    var total: Double {get}
}
extension PricePerUnit where Self : amount{
    func calTotalPrice(item: Self) -> Double {
        return self.unitPrice * item.amountTotal
    }
}
extension PricePerUnit{
    func isFasterthan(item: PricePerUnit) -> Bool {
        return self.unitPrice > item.unitPrice
    }
}
struct oilPrice: oilType, PricePerUnit,amount,totalPrice {
    var type: String
    var unitPrice: Double
    var amountTotal: Double
    var total: Double
}
//: Playground - noun: a place where people can play

import UIKit

let tutorialTeam = 56
let eidtorialTema = 23
var totalTeam = tutorialTeam+eidtorialTema
totalTeam += 1
let priceIntferred = -19
let priceIntExplicit:Int = -19
let pricedoubleferred = -19.99
let priceExplicit:Double = -19.99
let priceloatferred = -19.99
let pricefoaltExplicit:Float = -19.99

var shoopingLiistExplicit = [String]()
shoopingLiistExplicit = ["Eggs","Milk"]

var shoopingList = ["Eggs","Milk"]
print("The shooping list contains \(shoopingList.count) items.")
shoopingList.append("Flour")
shoopingList += ["baking powr"]
shoopingList += ["chocote spread","ceese","butter"]


var  fiestItem = shoopingList[0]
shoopingList[0] = "six eggs"

let array: Array<Int> = [1,2,3,4]
let dictionary: Dictionary<String, Int> = ["dog":1,"elephant":2]

var airports: [String: String] 








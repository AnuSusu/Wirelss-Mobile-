//: Playground - noun: a place where people can play

import UIKit

protocol Name {
    var name : string {get}
}

struct Person : Name {
    var name = String
}

let john = person(name : "anupong")

protocol Weght{
    var weght : float {get}
    
}

protocol High{
    var high : float{get}
    
}
struct BMI:Weght,High {
    var weght = 93
    var high = 1.61
}
let bmi = BMI()
let stdbmi = BMI(weght:161 ,high:65)
        
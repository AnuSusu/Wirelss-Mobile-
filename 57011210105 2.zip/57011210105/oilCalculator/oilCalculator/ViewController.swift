//
//  ViewController.swift
//  oilCalculator
//
//  Created by iClassroom on 11/8/16.
//  Copyright © 2016 iClassroom. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate {
    
    
    let prckerData = ["Sclcet Oil","Pepperoni","Deseil","Benzen"]
    var possiblePriceIncreases: [String: Double] = ["Benzen":22.11,"Deseil":10.4,"Pepperoni":50.8]
    var petrolCalc = oilPrice(type: "Benzen",unitPrice: 22,amountTotal: 10,total: 10)

    
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
            typePikker.dataSource = self
            typePikker.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func cal(sender: AnyObject) {
        
        let number = Double(amounttext.text!)
        petrolCalc.amountTotal = number!
        petrolCalc.unitPrice = Double(possiblePriceIncreases[petrolCalc.type]!)
        
        let value = petrolCalc.calTotalPrice(petrolCalc)
        petrolCalc.total = value
        
        print(petrolCalc)
        print("ราคาน้ำมันที่มีการปรับใหม่ = \(value)")
        
        tex.text = "ราคาน้ำมันที่มีการปรับชึ้นต่อลิตร \(petrolCalc.unitPrice)\nราคาน้ำมันที่มีการปรับขึ้น : \(value)"
        
    }
    @IBOutlet weak var amounttext: UITextField!
    
    @IBOutlet weak var typePikker: UIPickerView!
    

    @IBOutlet weak var tex: UITextView!

    
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return prckerData.count
    }
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return prckerData[row]
    }
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        petrolCalc.type = prckerData[row]
    }

}


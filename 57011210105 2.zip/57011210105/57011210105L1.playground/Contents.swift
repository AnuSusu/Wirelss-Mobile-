//: Playground - noun: a place where people can play

import UIKit

var str = "test let"

let tutorialTeam = 56
let editorialTeam = 23
var totalTeam = tutorialTeam + editorialTeam

totalTeam += 1
let priceIntInfrred = -19
let priceIntExplicit:Int = -19

let priceInferred = -19.99
let priceExplicit:Double = -19.99

let priceFloatInferred = -19.99
let priceFloatExplicit:Float = -19.99

let onSaleInferred = true
let onSaleExplicit:Bool = false

let nameInferred = "Whoopie Cushion"
let nameExplicit:String = "Whoopie Cushion"


var shoppingListExplicit = [String]()
shoppingListExplicit = ["Eggs","Milk"]
//var shoppingListExplicit:[String] = ["Eggs","Milk"]

var shoppingList = ["Eggs","Milk"]
print("The shopping list contains \(shoppingList.count) items.")
shoppingList.append("Flour")
shoppingList += ["Baking Powder"]
shoppingList += ["Chocolate Spread","Cheese","Butter"]
var firstItem = shoppingList[0]
shoppingList[0] = "Six Eggs"
//shoppingList[0...3] = ["Bananas","Apples"]
shoppingList

if (onSaleInferred){
    print("\(nameInferred) on sale for \(priceInferred)!")
}else{
    print("\(nameInferred) at regular price: \(priceInferred)!")
}

if (onSaleInferred){
    print("\(nameInferred) on sale for \(priceInferred)!")
}else{
    print("\(nameInferred) at regular price: \(priceInferred)!")
}

/*let shoppingListExplicit1 = [String]()
shoppingListExplicit1 = ["Eggs","Milk"]
//var shoppingListExplicit1:[String] = ["Eggs","Milk"]

let shoppingList1 = ["Eggs","Milk"]
print("The shopping list contains \(shoppingList.count) items.")
shoppingList1.append("Flour")
shoppingList1 += ["Baking Powder"]
shoppingList1 += ["Chocolate Spread","Cheese","Butter"]
let firstItem = shoppingList1[0]
shoppingList1[0] = "Six Eggs"
//shoppingList1[0...3] = ["Bananas","Apples"]
shoppingList1*/

let possibleTipsInferred = [0.15,0.18,0.20]
let possibleTipsExplicit:[Double] = [0.15,0.18,0.20]
var numberOfItem = possibleTipsInferred.count

shoppingList.isEmpty

shoppingList += ["Baking Powder"]
//shoppingList now contains 4 items
shoppingList += ["Chocolate Spread","Cheese","Butter"]
//shoppingList now contains 7 items
shoppingList.insert("Maple Syrup", atIndex: 0)
//shoppingList now contains 7 items
shoppingList.append("Flour")
shoppingList += ["Bahing Powder"]
var firsttItem = shoppingList[0]
shoppingList[4...6] = ["Bananas","Apples"]

let apples = shoppingList.removeLast()
let mapleSyrup = shoppingList.removeAtIndex(0)

//Dictionary

let array: Array<Int>= [1,2,3,4]
let dictionary: Dictionary<String,Int>=["dog":1,"elephant":2]

var airports:[String: String] = ["TY0":"Tokyo","DUB":"Dublin"]
if airports.isEmpty{
    print("The airports dictionary is empty.")
}else{
    print("The airports dictionary is not empty.")
}
//print("The airports dictionary is not empty.")
print("The airports dictionary contains \(airports.count) items.")
//The airports dictionary contains 2 items.

airports["LHR"] = "London"
//The airports dictionary contains 3 items.

airports["LHR"] = "London Heathrow"

if let oldValue = airports.updateValue("Dublin Iternational", forKey: "DUB"){
    print("The old value for DUB was \(oldValue).")
}
//The old value for DUB was Dublin.

airports["APL"] = "Applp Intrenational"
//"Apple Intrenational" is not the real airports for ALP, so delete it
airports["ALP"] = nil
//ALP. has now been removed from the dictionary
if let removeWalue = airports.removeValueForKey("DUB"){}









